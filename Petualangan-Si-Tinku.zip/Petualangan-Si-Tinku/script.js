let level = 1;
let boardSize = 10;
let tinku, goal, walls = [];

function startLevel1() {
  level = 1;
  document.getElementById("controlsLevel2").style.display = "none";
  document.getElementById("levelTitle").innerText = "Level 1: Tinku di Hutan";

  tinku = { x: 1, y: 1 };
  goal = { x: 8, y: 8 };
  walls = [
    [0,0],[1,0],[2,0],[3,0],[4,0],[5,0],[6,0],[7,0],[8,0],[9,0],
    [0,1],[9,1],
    [0,2],[9,2],
    [0,3],[4,3],[9,3],
    [0,4],[9,4],
    [0,5],[9,5],
    [0,6],[9,6],
    [0,7],[9,7],
    [0,8],[9,8],
    [0,9],[1,9],[2,9],[3,9],[4,9],[5,9],[6,9],[7,9],[8,9],[9,9]
  ];

  renderBoard();
  document.addEventListener("keydown", handleMove);
}

function startLevel2() {
  level = 2;
  document.getElementById("controlsLevel2").style.display = "block";
  document.getElementById("levelTitle").innerText = "Level 2: Tantangan Pola";

  tinku = { x: 1, y: 1 };
  goal = { x: 4, y: 4 };
  walls = [];

  langkahLangkah = [];
  renderBoard();
  renderLangkah();
  document.removeEventListener("keydown", handleMove);
}

function renderBoard() {
  const board = document.getElementById("gameBoard");
  board.innerHTML = "";
  board.style.gridTemplateColumns = `repeat(${boardSize}, 40px)`;
  board.style.gridTemplateRows = `repeat(${boardSize}, 40px)`;

  for (let y = 0; y < boardSize; y++) {
    for (let x = 0; x < boardSize; x++) {
      const cell = document.createElement("div");
      cell.classList.add("cell");

      if (walls.some(w => w[0] === x && w[1] === y)) {
        cell.classList.add("wall");
      }

      if (x === goal.x && y === goal.y) {
        cell.classList.add("target");
        cell.innerHTML = "🏠";
      }

      if (x === tinku.x && y === tinku.y) {
        cell.innerHTML = "<img src='https://emojicdn.elk.sh/🐢'>";
      }

      board.appendChild(cell);
    }
  }
}

function handleMove(e) {
  const key = e.key;
  let moved = false;

  if (key === "ArrowUp") {
    moved = moveTinku(0, -1);
  } else if (key === "ArrowDown") {
    moved = moveTinku(0, 1);
  } else if (key === "ArrowLeft") {
    moved = moveTinku(-1, 0);
  } else if (key === "ArrowRight") {
    moved = moveTinku(1, 0);
  }

  if (moved) {
    renderBoard();
    if (tinku.x === goal.x && tinku.y === goal.y) {
      setTimeout(() => {
        alert("Berhasil! Lanjut ke Level 2");
        startLevel2();
      }, 100);
    }
  }
}

function moveTinku(dx, dy) {
  const newX = tinku.x + dx;
  const newY = tinku.y + dy;

  if (
    newX >= 0 &&
    newX < boardSize &&
    newY >= 0 &&
    newY < boardSize &&
    !walls.some(w => w[0] === newX && w[1] === newY)
  ) {
    tinku.x = newX;
    tinku.y = newY;
    return true;
  }
  return false;
}

// ---------- LEVEL 2 ----------

let langkahLangkah = [];

function tambahLangkah(arah) {
  langkahLangkah.push(arah);
  renderLangkah();
}

function renderLangkah() {
  document.getElementById("langkahList").innerText = langkahLangkah.join(" ➡️ ");
}

function resetLangkah() {
  langkahLangkah = [];
  tinku = { x: 1, y: 1 };
  renderLangkah();
  renderBoard();
}

function jalankanLangkah() {
  let i = 0;
  function jalan() {
    if (i >= langkahLangkah.length) {
      if (tinku.x === goal.x && tinku.y === goal.y) {
        alert("Game Clear! Tinku sampai tujuan 🎉");
      } else {
        alert("Salah langkah 😢 Coba lagi!");
      }
      return;
    }

    const arah = langkahLangkah[i];
    if (arah === "up") moveTinku(0, -1);
    else if (arah === "down") moveTinku(0, 1);
    else if (arah === "left") moveTinku(-1, 0);
    else if (arah === "right") moveTinku(1, 0);

    renderBoard();
    i++;
    setTimeout(jalan, 500);
  }

  jalan();
}

startLevel1();
